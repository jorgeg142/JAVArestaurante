/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author GIGABYTE
 */
public class Conexion{
    private String base;
    private String usuario;
    private String host;
    private String contraseña;
    public static Connection con;

    public Conexion(String base, String usuario, String host, String contraseña) {
        this.base = base;
        this.usuario = usuario;
        this.host = host;
        this.contraseña = contraseña;
    }

    public Conexion() {
        this.base="comidarapida2";
        this.usuario="root";
        this.host="localhost";
        this.contraseña="";
    }

    public boolean conectar(){
        try {
            String url= "jdbc:mysql://"+this.host+"/"+this.base;
            Class.forName("com.mysql.cj.jdbc.Driver");
            con=DriverManager.getConnection(url, usuario, contraseña);
            return true;
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        } catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
     public void cerrar(){
        try {
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
     }


}
