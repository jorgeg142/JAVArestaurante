/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;
import static clases.Conexion.con;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.ResultSet;

/**
 *
 * @author GIGABYTE
 */
    public class Sentencias extends Conexion{
    Statement query;
    ResultSet rs;
    public Sentencias(){
        super();
    }
    public boolean insertarTabla(String sql){
        try {
            query=con.createStatement();
            query.executeUpdate(sql);
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(Sentencias.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
    public boolean EliminarTabla(String sql){
        try {
            query=con.createStatement();
            query.executeUpdate(sql);
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(Sentencias.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
    public static boolean isNumeric(String cadena){
    try {
        Integer.parseInt(cadena);
        return true;
    } catch (NumberFormatException nfe){
        return false;
    }
}
    public ResultSet consulta(String sql){
        try {
            query=con.createStatement();
            rs=query.executeQuery(sql);
        } catch (SQLException ex) {
            Logger.getLogger(Sentencias.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rs;
    }
    public boolean modificarTabla(String sql){
        try {
            query=con.createStatement();
            query.executeUpdate(sql);
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(Sentencias.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
}
